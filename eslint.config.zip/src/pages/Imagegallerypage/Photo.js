const photos = [
    {
      src: "https://cosmicenergiies.com/wp-content/uploads/2022/02/astro-vastu-consultant-jaipur-rajasthan-gurugram-gurgaon-shradha-sharma-8058000040-9-768x768.jpg",
      width: 1080,
      height: 780,
      alt: "Hiking boots",
    },
    {
      src: "https://cosmicenergiies.com/wp-content/uploads/2022/02/astro-vastu-consultant-jaipur-rajasthan-gurugram-gurgaon-shradha-sharma-8058000040-9-768x768.jpg",
      width: 1080,
      height: 1620,
      alt: "Purple petaled flowers near a mountain",
    },
    {
        src: "https://cosmicenergiies.com/wp-content/uploads/2022/02/astro-vastu-consultant-jaipur-rajasthan-gurugram-gurgaon-shradha-sharma-8058000040-9-768x768.jpg",
        width: 1080,
        height: 1620,
        alt: "Purple petaled flowers near a mountain",
      },
      {
        src: "https://cosmicenergiies.com/wp-content/uploads/2022/02/astro-vastu-consultant-jaipur-rajasthan-gurugram-gurgaon-shradha-sharma-8058000040-9-768x768.jpg",
        width: 1080,
        height: 1620,
        alt: "Purple petaled flowers near a mountain",
      },
      {
        src: "https://cosmicenergiies.com/wp-content/uploads/2022/02/astro-vastu-consultant-jaipur-rajasthan-gurugram-gurgaon-shradha-sharma-8058000040-9-768x768.jpg",
        width: 1080,
        height: 1620,
        alt: "Purple petaled flowers near a mountain",
      },
      {
        src: "https://cosmicenergiies.com/wp-content/uploads/2022/02/astro-vastu-consultant-jaipur-rajasthan-gurugram-gurgaon-shradha-sharma-8058000040-07-768x768.jpg",
        width: 1080,
        height: 1620,
        alt: "Purple petaled flowers near a mountain",
      },
  ];
  
  export default photos;
  