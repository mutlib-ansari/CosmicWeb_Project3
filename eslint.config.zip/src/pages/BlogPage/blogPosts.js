// export const blogPosts = [
//     { 
//       id: 1, 
//       title: 'First Blog Post', 
//       content: 'Full content of the first post...',
//       date: '2024-03-01', 
//       category: 'Vastu Basics',
//       excerpt: 'Learn about the basics of Vastu...'
//     },
//     { 
//         id: 2, 
//         title: 'First Blog Post', 
//         content: 'Full content of the first post...',
//         date: '2024-03-01', 
//         category: 'Vastu Basics',
//         excerpt: 'Learn about the basics of Vastu...'
//       },
//       { 
//         id: 3, 
//         title: 'First Blog Post', 
//         content: 'Full content of the first post...',
//         date: '2024-03-01', 
//         category: 'Vastu Basics',
//         excerpt: 'Learn about the basics of Vastu...'
//       },
//     // Add other posts...
//   ];

export const blogPosts = [
    { 
      id: 1, 
      title: 'First Blog Post', 
      content: 'Full content of the first post...',
      date: '2024-03-01', 
      category: 'Vastu Basics',
      excerpt: 'Learn about the basics of Vastu...'
    },
    { 
      id: 2, 
      title: 'Home Direction Tips', 
      content: 'Best directions for main entrance...',
      date: '2024-03-05', 
      category: 'Home Vastu',
      excerpt: 'Best directions for main entrance...'
    },
    { 
        id: 2, 
        title: 'Home Direction Tips', 
        content: 'Best directions for main entrance...',
        date: '2024-03-05', 
        category: 'Home Vastu',
        excerpt: 'Best directions for main entrance...'
      },
    // Add other posts...
  ];