// const videos = [
//     { src: "", alt: "Video 1" },
//     { src: "video2.mp4", alt: "Video 2" },
//     { src: "video3.mp4", alt: "Video 3" }
// ];

// export default videos;

const videos = [
    { src: "https://www.youtube.com/embed/WPoiaEeoO6s", alt: "Video 1" },  // Embed URL for YouTube
    { src: "https://www.youtube.com/embed/WPoiaEeoO6s", alt: "Video 2" },
    { src: "https://www.youtube.com/embed/WPoiaEeoO6s", alt: "Video 3" },
    { src: "https://www.youtube.com/embed/WPoiaEeoO6s", alt: "Video 4" },
    { src: "https://www.youtube.com/embed/WPoiaEeoO6s", alt: "Video 5" },
    { src: "https://www.youtube.com/embed/WPoiaEeoO6s", alt: "Video 7" },
    { src: "https://www.youtube.com/embed/WPoiaEeoO6s", alt: "Video 8" },
    { src: "https://www.youtube.com/embed/WPoiaEeoO6s", alt: "Video 9" },
    { src: "https://www.youtube.com/embed/WPoiaEeoO6s", alt: "Video 10" }
];

export default videos;

